import sqlite3

def get_db():
    conn = sqlite3.connect("expense.db")
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cur = conn.cursor()

    # USERS TABLE
    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT
    )
    """)

    # EXPENSES TABLE
    cur.execute("""
    CREATE TABLE IF NOT EXISTS expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        title TEXT,
        amount REAL,
        date TEXT
    )
    """)

    # --- SAFE COLUMN ADDITIONS ---
    try:
        cur.execute("ALTER TABLE users ADD COLUMN avatar_color TEXT")
    except sqlite3.OperationalError:
        pass  # column already exists

    try:
        cur.execute("ALTER TABLE users ADD COLUMN monthly_budget REAL")
    except sqlite3.OperationalError:
        pass  # column already exists

    conn.commit()
    conn.close()
