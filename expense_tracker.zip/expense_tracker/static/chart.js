function loadChart(chartData) {
    const ctx = document.getElementById('myChart').getContext('2d');

    new Chart(ctx, {
        type: 'pie',
        data: chartData,
        options: {
            responsive: true
        }
    });
}
