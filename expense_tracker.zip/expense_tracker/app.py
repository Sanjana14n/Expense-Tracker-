import sqlite3
from flask import Flask, render_template, request, redirect, session
from db import get_db, init_db
from datetime import datetime, timedelta


app = Flask(__name__)
app.secret_key = "expense_secret"

init_db()

# ---------------- LOGIN ----------------
@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        conn = get_db()
        cur = conn.cursor()
        cur.execute(
            "SELECT * FROM users WHERE username=? AND password=?",
            (username, password)
        )
        user = cur.fetchone()
        conn.close()

        if user:
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            return redirect("/dashboard")

    return render_template("login.html")


# ---------------- REGISTER ----------------
@app.route("/register", methods=["GET", "POST"])
def register():
    error = None

    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        conn = get_db()
        cur = conn.cursor()
        try:
            cur.execute(
                "INSERT INTO users (username, password) VALUES (?, ?)",
                (username, password)
            )
            conn.commit()
            conn.close()
            return redirect("/")
        except sqlite3.IntegrityError:
            error = "Username already exists"
            conn.close()

    return render_template("register.html", error=error)


# ---------------- DASHBOARD ----------------

@app.route("/dashboard")
def dashboard():
    if "user_id" not in session:
        return redirect("/")

    conn = get_db()
    cur = conn.cursor()

    # ---------------- EXPENSES ----------------
    cur.execute(
        "SELECT * FROM expenses WHERE user_id=?",
        (session["user_id"],)
    )
    expenses = cur.fetchall()

    total = sum(e["amount"] for e in expenses)

    # ---------------- TODAY ----------------
    today = datetime.now().strftime("%Y-%m-%d")
    today_total = sum(e["amount"] for e in expenses if e["date"] == today)

    # ---------------- THIS MONTH ----------------
    current_month = datetime.now().strftime("%Y-%m")
    month_total = sum(
        e["amount"] for e in expenses if e["date"].startswith(current_month)
    )

    # ---------------- SALARY ----------------
    cur.execute(
        "SELECT salary FROM users WHERE id=?",
        (session["user_id"],)
    )
    row = cur.fetchone()
    salary = row["salary"] if row and row["salary"] is not None else 0

    balance = salary - total

    # ---------------- ANALYTICS ----------------

    # Highest expense
    highest = max(expenses, key=lambda e: e["amount"], default=None)
    highest_amount = highest["amount"] if highest else 0
    highest_title = highest["title"] if highest else "N/A"

    # Average per day
    unique_days = set(e["date"] for e in expenses)
    avg_per_day = round(total / len(unique_days), 2) if unique_days else 0

    # Last month comparison
    last_month = (datetime.now().replace(day=1) - timedelta(days=1)).strftime("%Y-%m")

    cur.execute(
        "SELECT amount FROM expenses WHERE user_id=? AND date LIKE ?",
        (session["user_id"], f"{last_month}%")
    )
    last_month_total = sum(r["amount"] for r in cur.fetchall())

    conn.close()

    # ---------------- RENDER ----------------
    return render_template(
        "dashboard.html",
        expenses=expenses,
        total=total,
        today_total=today_total,
        month_total=month_total,
        salary=salary,
        balance=balance,
        highest_amount=highest_amount,
        highest_title=highest_title,
        avg_per_day=avg_per_day,
        this_month_total=month_total,
        last_month_total=last_month_total,
        username=session["username"]
    )


# ---------------- ADD EXPENSE ----------------
@app.route("/add", methods=["GET", "POST"])
def add_expense():
    if "user_id" not in session:
        return redirect("/")

    if request.method == "POST":
        title = request.form["title"]
        amount = float(request.form["amount"])
        date = request.form.get("date") or datetime.now().strftime("%Y-%m-%d")

        conn = get_db()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO expenses (user_id, title, amount, date) VALUES (?,?,?,?)",
            (session["user_id"], title, amount, date)
        )
        conn.commit()
        conn.close()

        return redirect("/dashboard")

    return render_template("add_expense.html")

# ---------------- EDIT EXPENSE ----------------
@app.route("/edit/<int:expense_id>", methods=["GET", "POST"])
def edit_expense(expense_id):
    if "user_id" not in session:
        return redirect("/")

    conn = get_db()
    cur = conn.cursor()

    if request.method == "POST":
        title = request.form["title"]
        amount = float(request.form["amount"])
        date = request.form["date"]

        cur.execute(
            """
            UPDATE expenses
            SET title=?, amount=?, date=?
            WHERE id=? AND user_id=?
            """,
            (title, amount, date, expense_id, session["user_id"])
        )
        conn.commit()
        conn.close()
        return redirect("/dashboard")

    # GET request – fetch expense
    cur.execute(
        "SELECT * FROM expenses WHERE id=? AND user_id=?",
        (expense_id, session["user_id"])
    )
    expense = cur.fetchone()
    conn.close()

    if not expense:
        return redirect("/dashboard")

    return render_template("edit_expense.html", expense=expense)


# ---------------- REPORT ----------------@app.route("/report")
@app.route("/report")
def report():
    if "user_id" not in session:
        return redirect("/")

    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        "SELECT title, amount FROM expenses WHERE user_id=?",
        (session["user_id"],)
    )
    rows = cur.fetchall()
    conn.close()

    data = [{"title": r["title"], "amount": r["amount"]} for r in rows]

    return render_template("report.html", data=data)


# ---------------- DELETE ----------------
@app.route("/delete/<int:expense_id>")
def delete_expense(expense_id):
    if "user_id" not in session:
        return redirect("/")

    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        "DELETE FROM expenses WHERE id=? AND user_id=?",
        (expense_id, session["user_id"])
    )
    conn.commit()
    conn.close()

    return redirect("/dashboard")


# ---------------- MONTHLY SUMMARY ----------------
@app.route("/monthly", methods=["GET", "POST"])
def monthly_summary():
    if "user_id" not in session:
        return redirect("/")

    expenses = []
    total = 0
    month = None

    if request.method == "POST":
        month = request.form["month"]  # YYYY-MM

        conn = get_db()
        cur = conn.cursor()
        cur.execute(
            "SELECT title, amount, date FROM expenses WHERE user_id=? AND date LIKE ?",
            (session["user_id"], f"{month}%")
        )
        expenses = cur.fetchall()
        conn.close()

        total = sum(e["amount"] for e in expenses)

    return render_template(
        "monthly.html",
        expenses=expenses,
        total=total,
        month=month
    )

@app.route("/set-salary", methods=["GET", "POST"])
def set_salary():
    if "user_id" not in session:
        return redirect("/")

    if request.method == "POST":
        salary = float(request.form["salary"])

        conn = get_db()
        cur = conn.cursor()
        cur.execute(
            "UPDATE users SET salary=? WHERE id=?",
            (salary, session["user_id"])
        )
        conn.commit()
        conn.close()

        return redirect("/dashboard")

    return render_template("set_salary.html")

# ---------------- CHANGE PASSWORD ----------------
@app.route("/change-password", methods=["GET", "POST"])
def change_password():
    if "user_id" not in session:
        return redirect("/")

    error = None
    success = None

    if request.method == "POST":
        old_password = request.form["old_password"]
        new_password = request.form["new_password"]
        confirm_password = request.form["confirm_password"]

        conn = get_db()
        cur = conn.cursor()

        # check old password
        cur.execute(
            "SELECT password FROM users WHERE id=?",
            (session["user_id"],)
        )
        user = cur.fetchone()

        if not user or user["password"] != old_password:
            error = "Old password is incorrect"
        elif new_password != confirm_password:
            error = "New passwords do not match"
        else:
            cur.execute(
                "UPDATE users SET password=? WHERE id=?",
                (new_password, session["user_id"])
            )
            conn.commit()
            success = "Password changed successfully"

        conn.close()

    return render_template(
        "change_password.html",
        error=error,
        success=success
    )


# ---------------- LOGOUT ----------------
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")


if __name__ == "__main__":
    app.run(debug=True)
