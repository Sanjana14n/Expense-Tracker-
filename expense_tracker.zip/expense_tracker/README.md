Expense Tracker using Flask

Features:
- Login system
- Add expenses
- View total
- Pie chart report
- SQLite database
