from db import get_db

conn = get_db()
cur = conn.cursor()

cur.execute(
    "INSERT INTO users (username, password) VALUES (?, ?)",
    ("admin", "admin123")
)

conn.commit()
conn.close()

print("User added")
