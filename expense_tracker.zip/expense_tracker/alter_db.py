import sqlite3

conn = sqlite3.connect("expense.db")
cur = conn.cursor()

cur.execute("ALTER TABLE expenses ADD COLUMN category TEXT")

conn.commit()
conn.close()

print("Category column added")
